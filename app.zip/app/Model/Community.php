<?php

App::uses('AppModel', 'Model');


class Community extends AppModel {
      public $primaryKey = 'id';
    
}