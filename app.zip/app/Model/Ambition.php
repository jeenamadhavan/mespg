<?php

App::uses('AppModel', 'Model');
class Ambition extends AppModel {
      public $primaryKey = 'id';
    
}