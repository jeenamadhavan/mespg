<?php

App::uses('AppModel', 'Model');


class Religion extends AppModel {
      public $primaryKey = 'id';
    
}