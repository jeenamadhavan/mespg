<?php

App::uses('AppModel', 'Model');
class District extends AppModel {
      public $primaryKey = 'id';
    
}