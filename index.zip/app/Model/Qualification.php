<?php

App::uses('AppModel', 'Model');


class Qualification extends AppModel {
      public $primaryKey = 'id';
    
}