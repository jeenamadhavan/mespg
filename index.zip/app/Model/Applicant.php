<?php

App::uses('AppModel', 'Model');
/*
 * Author : Ashifa TK
 * Purpose : Paymentterm Database operatons.
 * Date : 8/25/2014
 */

class Applicant extends AppModel {
      public $primaryKey = 'frkApplicantID';
    
}