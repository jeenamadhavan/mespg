<?php

App::uses('AppModel', 'Model');


class Occupation extends AppModel {
      public $primaryKey = 'id';
    
}