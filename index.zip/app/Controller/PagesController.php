<?php

/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class PagesController extends AppController {

    /**
     * This controller does not use a model
     *
     * @var array
     */
    public $uses = array(
        'Ambition',
        'Country',
        'Contact',
        'Religion',
        'District',
        'Qualification',
        'Occupation',
        'Community',
        'State',
        'User',
        'Applicant',
        'Generatenumber',
        'Course',
    );
    var $name = 'Pages';
    public $helpers = array('Html', 'Form', 'Session');

    /**
     * Displays a view
     *
     * @return void
     * @throws NotFoundException When the view file could not be found
     * 	or MissingViewException in debug mode.
     */
    public function index() {


        if ($this->request->is('post')) {


            $validates = array();
            $msg = "";
            $email = $this->request->data['UserForm']['frkUserEmail'];
            $password = $this->request->data['UserForm']['frkUserPassword'];
            $repeatpassword = $this->request->data['UserForm']['frkRepeatUserPassword'];
            $remember = $this->request->data['remember'];

            if ($email == null) {
                $validates[1] = 'Email Should Not Be Empty';
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $validates[2] = "Invalid email format";
            }
            if ($password == null) {
                $validates[3] = 'Password Should Not Be Empty';
            }
            if ($repeatpassword == null) {
                $validates[4] = 'Password Repeat Should Not Be Empty';
            }
            if ($repeatpassword != $password) {
                $validates[5] = 'Password does not Matches';
            }
            $checkexist = $this->User->find('first', array(
                'conditions' => array(
                    'User.frkUserEmail' => $email
                )
                    ));
            if (count($checkexist) != 0) {
                $validates[6] = 'User with this Email Already Exist';
            }

            if ($validates != null) {
                foreach ($validates as $messages) {
                    $msg = $messages . '. ' . $msg . "<br>";
                }
                $this->Session->setFlash(__($msg));
                return $this->redirect(array('action' => 'index'));
            } else {

                $savedata = array(
                    'frkUserEmail' => $email,
                    'frkUserRole' => 'A',
                    'frkUserPassword' => base64_encode($password),
                    'frkRandomString' => $this->randStrGen(20),
                    'frkUserCreatedDate' => date('Y-m-d'),
                );
                $this->User->create();
                $user = $this->User->save($savedata);
                if (!empty($user)) {
                    $this->_sendNewUserMail($user['User']['frkRandomString'], $user['User']['frkUserID'], $user['User']['frkUserEmail']);
                    $this->Session->setFlash(__('We have sent one confirmation link to your email address,kindly confirm your email.Thank you!'));
                } else {
                    $this->Session->setFlash(__('The user could not be saved. Please, try again.'));
                }
            }
        }
    }

    public function checkpasswords() {

        if (strcmp($this->request->data['User']['frkUserPassword'], $this->request->data['User']['frkRepeatUserPassword']) == 0) {
            return true;
        }
        return false;
    }

    public function randStrGen($len) {
        $result = "";
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        $charArray = str_split($chars);
        for ($i = 0; $i < $len; $i++) {
            $randItem = array_rand($charArray);
            $result .= "" . $charArray[$randItem];
        }
        return $result;
    }

    public function _sendNewUserMail($randomstring, $id, $to) {

        $baseurl = Router::url('/', true);
        $link = $baseurl . "users/confirmationlink/" . $randomstring . "/" . $id;
        //echo $this->Html->link('dfgdgdg');die();
        $subject = 'Confirm Your Email';
        $message1 = "Hello User, You signed up at this site,Your account is almost ready,but befor you can login you need to confirm your emai address by visiting the link below<br>";
        $message2 = "<a href='" . $link . "'>" . $link . "</a><br>Once you have visited the verification URL your account will be activated Thanks, Team.";
        $message = $message1 . $message2;
        $headers = 'From: admissions@example.com' . "\r\n" .
                'Reply-To: admissions@example.com' . "\r\n" .
                'X-Mailer: PHP/' . phpversion();

        mail($to, $subject, $message, $headers);
    }

    public function confirmationlink($randomstring = NULL, $id = NULL) {

        $result = $this->User->find('first', array(
            'conditions' => array('frkUserID' => $id),
            'fields' => array('frkRandomString')
                ));
        if (isset($result['User']['frkRandomString']) && $result['User']['frkRandomString'] != " ") {
            $sql = "UPDATE `farook`.`users` SET `frkUserStatus` = '1', `frkRandomString` = '' WHERE `users`.`frkUserID` = " . $id . "; ";
            $usercredentials = $this->User->query($sql);
            $this->Session->setFlash(__('Congratulation,Your Account is Activated!'));
            $this->redirect(array('action' => 'index', 'controller' => 'pages'));
        } else {
            $this->Session->setFlash(__('You can access the link only once'));
        }
    }

    public function login() {
        $this->Session->setFlash(__('Please Login to Continue!'));
        if ($this->request->is('post')) {

            $encryptpassword = base64_encode($this->request->data['UserLogin']['password']);
            $usersDetails = $this->User->find('first', array(
                'conditions' => array(
                    'User.frkUserEmail' => $this->request->data['UserLogin']['email'],
                    'User.frkUserPassword' => $encryptpassword,
                    'User.frkUserStatus' => 1,
                )
                    ));
            if (count($usersDetails) == 0) {
                $this->Session->setFlash(__('The User Not Found or User Not Verified.'));
                return $this->redirect(array('action' => 'login'));
            } else {
                //create new session varialble
                $this->Session->write('User.userid', $usersDetails['User']['frkUserID']);
                $this->Session->write('User.email', $usersDetails['User']['frkUserEmail']);

                return $this->redirect(array('action' => 'primary_registration'));
            }
        }
    }

    public function logout() {
        $this->Session->delete('User');
        $this->Session->setFlash(__('Good bye!'));
        return $this->redirect(array('action' => 'index'));
    }

    public function primary_registration() {
        $userid = $this->Session->read('User.userid');
        if (!isset($userid)) {
            $this->Session->setFlash(__('Please Login!.'));
            return $this->redirect(array('action' => 'login'));
        } else {
            $users = $this->User->find('first', array(
                'conditions' => array(
                    'frkUserID' => $userid
                )
                    ));
            $applicant = $this->Applicant->find('first', array(
                'conditions' => array(
                    'frkUserID' => $userid
                )
                    ));

            @$entranceData = array(
                'med' => $applicant['Applicant']['frkApplicantEntranceMedical'],
                'eng' => $applicant['Applicant']['frkApplicantEntranceEngineering'],
                'iit' => $applicant['Applicant']['frkApplicantEntranceIIT'],
                'jee' => $applicant['Applicant']['frkApplicantEntranceJEE'],
                'aitmt' => $applicant['Applicant']['frkAITMT'],
                'aiims' => $applicant['Applicant']['frkAILMS'],
                'jitmer' => $applicant['Applicant']['frkJITMER'],
                'ali' => $applicant['Applicant']['frkALIGARH'],
                'wardhah' => $applicant['Applicant']['frkWARDHAH'],
                'amrita' => $applicant['Applicant']['frkAMRITA'],
                'manipal' => $applicant['Applicant']['frkMANIPAL'],
                'vellore' => $applicant['Applicant']['frkVELLORE'],
                'other' => $applicant['Applicant']['frkOTHER'],
            );
            $appenddata = array();
            $appenddata['PrimaryRegister']['name'] = $users['User']['frkName'];
            $appenddata['PrimaryRegister']['email'] = $users['User']['frkUserEmail'];
            $appenddata['PrimaryRegister']['adhaar'] = $users['User']['frkUserAdhaarNo'];
            $appenddata['PrimaryRegister']['blood'] = $users['User']['frkUserBloodGroup'];
            $appenddata['PrimaryRegister']['religion'] = $users['User']['frkUserReligion'];
            $appenddata['PrimaryRegister']['religion-other'] = $users['User']['frkUserReligion'];
            if ($users['User']['frkUserDOB'] != '0000-00-00') {
                $appenddata['PrimaryRegister']['dob'] = date("d/m/Y", strtotime($users['User']['frkUserDOB']));
            }
            $appenddata['PrimaryRegister']['father-name'] = $users['User']['frkFatherName'];
            $appenddata['PrimaryRegister']['father-qualification'] = $users['User']['frkFatherQualification'];
            $appenddata['PrimaryRegister']['father-qualification-other'] = $users['User']['frkFatherQualification'];
            $appenddata['PrimaryRegister']['father-occupation'] = $users['User']['frkFatherOccupation'];
            $appenddata['PrimaryRegister']['father-occupation-other'] = $users['User']['frkFatherOccupation'];
            $appenddata['PrimaryRegister']['gender'] = $users['User']['frkUserGender'];
            $appenddata['PrimaryRegister']['mobile'] = $users['User']['frkUserMobile'];
            $appenddata['PrimaryRegister']['nationality'] = $users['User']['frkUserNationality_ID'];
            $appenddata['PrimaryRegister']['community'] = $users['User']['frkUserCommunity'];
            $appenddata['PrimaryRegister']['community-other'] = $users['User']['frkUserCommunity'];
            $appenddata['PrimaryRegister']['placeofbirth'] = $users['User']['frkUserPOB'];
            $appenddata['PrimaryRegister']['mother-name'] = $users['User']['frkMotherName'];
            $appenddata['PrimaryRegister']['mother-qualification'] = $users['User']['frkMotherQualification'];
            $appenddata['PrimaryRegister']['mother-qualification-other'] = $users['User']['frkMotherQualification'];
            $appenddata['PrimaryRegister']['mother-occupation'] = $users['User']['frkMotherOccupation'];
            $appenddata['PrimaryRegister']['mother-occupation-other'] = $users['User']['frkMotherOccupation'];
            $appenddata['PrimaryRegister']['perma-addline1'] = $users['User']['frkUserAddressline1'];
            $appenddata['PrimaryRegister']['perma-addline2'] = $users['User']['frkUserAddressline2'];
            $appenddata['PrimaryRegister']['perma-postoffice'] = $users['User']['frkUserTaluk'];
            $appenddata['PrimaryRegister']['perma-pincode'] = $users['User']['frkUserPincode'];
            $appenddata['PrimaryRegister']['perma-city'] = $users['User']['frkUserDistrict'];
            $appenddata['PrimaryRegister']['perma-city-other'] = $users['User']['frkUserDistrict'];
            $appenddata['PrimaryRegister']['perma-state'] = $users['User']['frkUserState'];
            $appenddata['PrimaryRegister']['perma-state-other'] = $users['User']['frkUserState'];
            $appenddata['PrimaryRegister']['perma-country'] = $users['User']['frkUserCountry_ID'];
            $appenddata['PrimaryRegister']['comm-addline1'] = $users['User']['frkUserCommAddressline1'];
            $appenddata['PrimaryRegister']['comm-addline2'] = $users['User']['frkUserCommAddressline2'];
            $appenddata['PrimaryRegister']['comm-postoffice'] = $users['User']['frkUserCommTaluk'];
            $appenddata['PrimaryRegister']['comm-pincode'] = $users['User']['frkUserCommPincode'];
            $appenddata['PrimaryRegister']['comm-city'] = $users['User']['frkUserCommDistrict'];
            $appenddata['PrimaryRegister']['comm-city-other'] = $users['User']['frkUserCommDistrict'];
            $appenddata['PrimaryRegister']['comm-state'] = $users['User']['frkUserCommState'];
            $appenddata['PrimaryRegister']['comm-state-other'] = $users['User']['frkUserCommState'];
            $appenddata['PrimaryRegister']['comm-country'] = $users['User']['frkUserCommCountryID'];
            $appenddata['PrimaryRegister']['phonestd'] = $users['User']['frkPhoneStd'];
            $appenddata['PrimaryRegister']['phonenumber'] = $users['User']['frkPhoneNumber'];
            if ($applicant != null) {
                $appenddata['PrimaryRegister']['qualifyingexam'] = $applicant['Applicant']['frkTenth'];
                $appenddata['PrimaryRegister']['otherqualifyingexam'] = $applicant['Applicant']['frkTenth'];
                $appenddata['PrimaryRegister']['ten-school'] = $applicant['Applicant']['frkTenthSchool'];
                $appenddata['PrimaryRegister']['tenyearofstudy'] = $applicant['Applicant']['frkTenthYOS'];
                $appenddata['PrimaryRegister']['TenYearofPassing'] = $applicant['Applicant']['frlTenthYOP'];
                $appenddata['PrimaryRegister']['tenthRegno'] = $applicant['Applicant']['frkTenthRegno'];
                $appenddata['PrimaryRegister']['carrer-ambition'] = $applicant['Applicant']['frkApplicantAmbition'];
                $appenddata['PrimaryRegister']['other-carrer-ambition'] = $applicant['Applicant']['frkApplicantAmbition'];
            }
            $countries = $this->Country->find('list', array('fields' => array('id', 'country_name')));
            $religions = $this->Religion->find('list', array('fields' => array('id', 'name')));
            $qualifications = $this->Qualification->find('list', array('fields' => array('id', 'name')));
            $occupations = $this->Occupation->find('list', array('fields' => array('id', 'name')));
            $communities = $this->Community->find('list', array('fields' => array('id', 'name')));
            $states = $this->State->find('list', array('fields' => array('id', 'name')));
            $districts = $this->District->find('list', array('fields' => array('id', 'name')));
            $ambitions = $this->Ambition->find('list', array('fields' => array('id', 'name')));


            $communities['other'] = 'Other';
            $religions['other'] = 'Other';
            $qualifications['other'] = 'Other';
            $occupations['other'] = 'Other';
            $states['other'] = 'Other';
            $districts['other'] = 'Other';
            $ambitions['other'] = 'Other';
            if ($this->request->is('post')) {
                if ($this->request->data['PrimaryRegister']['religion'] != 'other') {
                    $userRelegion = $this->request->data['PrimaryRegister']['religion'];
                } else {
                    $userRelegion = $this->request->data['PrimaryRegister']['religion-other'];
                }
                if ($this->request->data['PrimaryRegister']['father-qualification'] != 'other') {
                    $userFatherQualification = $this->request->data['PrimaryRegister']['father-qualification'];
                } else {
                    $userFatherQualification = $this->request->data['PrimaryRegister']['father-qualification-other'];
                }
                if ($this->request->data['PrimaryRegister']['father-occupation'] != 'other') {
                    $userFatherOccupation = $this->request->data['PrimaryRegister']['father-occupation'];
                } else {
                    $userFatherOccupation = $this->request->data['PrimaryRegister']['father-occupation-other'];
                }
                if ($this->request->data['PrimaryRegister']['community'] != 'other') {
                    $userCommunity = $this->request->data['PrimaryRegister']['community'];
                } else {
                    $userCommunity = $this->request->data['PrimaryRegister']['community-other'];
                }
                if ($this->request->data['PrimaryRegister']['mother-qualification'] != 'other') {
                    $userMotherQualification = $this->request->data['PrimaryRegister']['mother-qualification'];
                } else {
                    $userMotherQualification = $this->request->data['PrimaryRegister']['mother-qualification-other'];
                }
                if ($this->request->data['PrimaryRegister']['mother-occupation'] != 'other') {
                    $userMotherOccupation = $this->request->data['PrimaryRegister']['mother-occupation'];
                } else {
                    $userMotherOccupation = $this->request->data['PrimaryRegister']['mother-occupation-other'];
                }
                if ($this->request->data['PrimaryRegister']['perma-state'] != 'other') {
                    $PermaState = $this->request->data['PrimaryRegister']['perma-state'];
                } else {
                    $PermaState = $this->request->data['PrimaryRegister']['perma-state-other'];
                }
                if ($this->request->data['PrimaryRegister']['comm-state'] != 'other') {
                    $CommState = $this->request->data['PrimaryRegister']['comm-state'];
                } else {
                    $CommState = $this->request->data['PrimaryRegister']['comm-state-other'];
                }
                if ($this->request->data['PrimaryRegister']['comm-city'] != 'other') {
                    $CommState = $this->request->data['PrimaryRegister']['comm-city'];
                } else {
                    $CommState = $this->request->data['PrimaryRegister']['comm-city-other'];
                }
                if ($this->request->data['PrimaryRegister']['perma-city'] != 'other') {
                    $CommState = $this->request->data['PrimaryRegister']['perma-city'];
                } else {
                    $CommState = $this->request->data['PrimaryRegister']['perma-city-other'];
                }
                $dob = $this->request->data['PrimaryRegister']['dob'];
                $date = str_replace('/', '-', $dob);
                $newdob = date('Y-m-d', strtotime($date));
                $userTabaleSaveData = array(
                    'frkName' => "'" . $this->request->data['PrimaryRegister']['name'] . "'",
                    'frkUserEmail' => "'" . $this->request->data['PrimaryRegister']['email'] . "'",
                    'frkUserAdhaarNo' => "'" . $this->request->data['PrimaryRegister']['adhaar'] . "'",
                    'frkUserBloodGroup' => "'" . $this->request->data['PrimaryRegister']['blood'] . "'",
                    'frkUserReligion' => "'" . $userRelegion . "'",
                    'frkUserDOB' => "'" . $newdob . "'",
                    'frkFatherName' => "'" . $this->request->data['PrimaryRegister']['father-name'] . "'",
                    'frkFatherQualification' => "'" . $userFatherQualification . "'",
                    'frkFatherOccupation' => "'" . $userFatherOccupation . "'",
                    'frkUserGender' => "'" . $this->request->data['PrimaryRegister']['gender'] . "'",
                    'frkUserMobile' => "'" . $this->request->data['PrimaryRegister']['mobile'] . "'",
                    'frkUserNationality_ID' => $this->request->data['PrimaryRegister']['nationality'],
                    'frkUserCommunity' => "'" . $userCommunity . "'",
                    'frkUserPOB' => "'" . $this->request->data['PrimaryRegister']['placeofbirth'] . "'",
                    'frkMotherName' => "'" . $this->request->data['PrimaryRegister']['mother-name'] . "'",
                    'frkMotherQualification' => "'" . $userMotherQualification . "'",
                    'frkMotherOccupation' => "'" . $userMotherOccupation . "'",
                    'frkUserAddressline1' => "'" . $this->request->data['PrimaryRegister']['perma-addline1'] . "'",
                    'frkUserAddressline2' => "'" . $this->request->data['PrimaryRegister']['perma-addline2'] . "'",
                    'frkUserTaluk' => "'" . $this->request->data['PrimaryRegister']['perma-postoffice'] . "'",
                    'frkUserDistrict' => "'" . $this->request->data['PrimaryRegister']['perma-city'] . "'",
                    'frkUserState' => "'" . $PermaState . "'",
                    'frkUserPincode' => "'" . $this->request->data['PrimaryRegister']['perma-pincode'] . "'",
                    'frkUserCountry_ID' => $this->request->data['PrimaryRegister']['perma-country'],
                    'frkUserCommAddressline1' => "'" . $this->request->data['PrimaryRegister']['comm-addline1'] . "'",
                    'frkUserCommAddressline2' => "'" . $this->request->data['PrimaryRegister']['comm-addline2'] . "'",
                    'frkUserCommTaluk' => "'" . $this->request->data['PrimaryRegister']['comm-postoffice'] . "'",
                    'frkUserCommDistrict' => "'" . $this->request->data['PrimaryRegister']['comm-city'] . "'",
                    'frkUserCommState' => "'" . $CommState . "'",
                    'frkUserCommPincode' => "'" . $this->request->data['PrimaryRegister']['comm-pincode'] . "'",
                    'frkUserCommCountryID' => $this->request->data['PrimaryRegister']['comm-country'],
                    'frkPhoneStd' => "'" . $this->request->data['PrimaryRegister']['phonestd'] . "'",
                    'frkPhoneNumber' => "'" . $this->request->data['PrimaryRegister']['phonenumber'] . "'",
                );
                if ($this->request->data['PrimaryRegister']['carrer-ambition'] != 'other') {
                    $careerAmbition = $this->request->data['PrimaryRegister']['carrer-ambition'];
                } else {
                    $careerAmbition = $this->request->data['PrimaryRegister']['other-carrer-ambition'];
                }
                if ($this->request->data['PrimaryRegister']['qualifyingexam'] != 'other') {
                    $QualiExamTenth = $this->request->data['PrimaryRegister']['qualifyingexam'];
                } else {
                    $QualiExamTenth = $this->request->data['PrimaryRegister']['otherqualifyingexam'];
                }
                $applicantdetails = $this->Applicant->find('first', array(
                    'conditions' => array(
                        'Applicant.frkUserID' => $userid
                    )
                        ));
                $numbergen = $this->Generatenumber->find('first', array(
                    'conditions' => array(
                        'Generatenumber.typecode' => 1
                    )
                        ));
                $tempAppNumber = $numbergen['Generatenumber']['currvalue'] + 1;
                $remindigits = 6 - strlen($tempAppNumber);
                if ($remindigits == 5) {
                    $ApplicationNumber = 'FKUG00000' . $tempAppNumber;
                } elseif ($remindigits == 4) {
                    $ApplicationNumber = 'FKUG0000' . $tempAppNumber;
                } elseif ($remindigits == 3) {
                    $ApplicationNumber = 'FKUG000' . $tempAppNumber;
                } elseif ($remindigits == 2) {
                    $ApplicationNumber = 'FKUG00' . $tempAppNumber;
                } elseif ($remindigits == 1) {
                    $ApplicationNumber = 'FKUG0' . $tempAppNumber;
                } else {
                    $ApplicationNumber = 'FKUG' . $tempAppNumber;
                }
                $cnd3 = array(
                    'Generatenumber.typecode' => 1,
                );
                $fld3 = array(
                    'currvalue' => $tempAppNumber,
                );
                if (!$this->Generatenumber->updateAll($fld3, $cnd3)) {
                    $this->Session->setFlash(__('Application Number Not Generated'));
                    return $this->redirect(array('action' => 'primary_registration'));
                }

                $cnd = array(
                    'User.frkUserID' => $userid,
                );
                $cnd2 = array(
                    'Applicant.frkUserID' => $userid,
                );
                if (!$this->User->updateAll($userTabaleSaveData, $cnd)) {
                    $this->Session->setFlash(__('Could not Save Application Data'));
                    return $this->redirect(array('action' => 'primary_registration'));
                }








                if (isset($this->request->data['PrimaryRegister']['keralmedical'][0])) {
                    $keralamedical = 'Yes';
                } else {
                    $keralamedical = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['keralengg'][0])) {
                    $keralaengg = 'Yes';
                } else {
                    $keralaengg = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['iit'][0])) {
                    $iit = 'Yes';
                } else {
                    $iit = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['jee'][0])) {
                    $jee = 'Yes';
                } else {
                    $jee = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['aitmt'][0])) {
                    $aitmt = 'Yes';
                } else {
                    $aitmt = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['aiims'][0])) {
                    $aiims = 'Yes';
                } else {
                    $aiims = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['jitmer'][0])) {
                    $jitmer = 'Yes';
                } else {
                    $jitmer = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['ali'][0])) {
                    $ali = 'Yes';
                } else {
                    $ali = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['wardhah'][0])) {
                    $wardhah = 'Yes';
                } else {
                    $wardhah = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['amrita'][0])) {
                    $amrita = 'Yes';
                } else {
                    $amrita = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['manipal'][0])) {
                    $manipal = 'Yes';
                } else {
                    $manipal = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['vellore'][0])) {
                    $vellore = 'Yes';
                } else {
                    $vellore = 'No';
                }
                if (isset($this->request->data['PrimaryRegister']['other'][0])) {
                    $other = 'Yes#' . $this->request->data['PrimaryRegister']['entrance-other'];
                } else {
                    $other = 'No';
                }











                if (count($applicantdetails) > 0) {
                    $ApplicantTableData = array(
                        'frkApplicantAmbition' => "'" . $careerAmbition . "'",
                        'frkTenthSchool' => "'" . $this->request->data['PrimaryRegister']['ten-school'] . "'",
                        'frkTenthRegno' => "'" . $this->request->data['PrimaryRegister']['tenthRegno'] . "'",
                        'frkTenthYOS' => "'" . $this->request->data['PrimaryRegister']['tenyearofstudy'] . "'",
                        'frlTenthYOP' => "'" . $this->request->data['PrimaryRegister']['TenYearofPassing'] . "'",
                        'frkTenth' => "'" . $QualiExamTenth . "'",
                        'frkApplicantEntranceMedical' => "'" . $keralamedical . "'",
                        'frkApplicantEntranceEngineering' => "'" . $keralaengg . "'",
                        'frkApplicantEntranceIIT' => "'" . $iit . "'",
                        'frkApplicantEntranceJEE' => "'" . $jee . "'",
                        'frkAITMT' => "'" . $aitmt . "'",
                        'frkAILMS' => "'" . $aiims . "'",
                        'frkJITMER' => "'" . $jitmer . "'",
                        'frkALIGARH' => "'" . $ali . "'",
                        'frkWARDHAH' => "'" . $wardhah . "'",
                        'frkAMRITA' => "'" . $amrita . "'",
                        'frkMANIPAL' => "'" . $manipal . "'",
                        'frkVELLORE' => "'" . $vellore . "'",
                        'frkOTHER' => "'" . $other . "'",
                    );
                    if (!$this->Applicant->updateAll($ApplicantTableData, $cnd2)) {
                        $this->Session->setFlash(__('Could not Save Application Data'));
                        return $this->redirect(array('action' => 'primary_registration'));
                    }
                } else {
                    $ApplicantTableData = array(
                        'frkUserID' => $userid,
                        'frkApplicantAmbition' => $careerAmbition,
                        'frkApplicationNumber' => $ApplicationNumber,
                        'frkTenthSchool' => $this->request->data['PrimaryRegister']['ten-school'],
                        'frkTenthRegno' => $this->request->data['PrimaryRegister']['tenthRegno'],
                        'frkTenthYOS' => $this->request->data['PrimaryRegister']['tenyearofstudy'],
                        'frlTenthYOP' => $this->request->data['PrimaryRegister']['TenYearofPassing'],
                        'frkTenth' => $QualiExamTenth,
                        'frkApplicantEntranceMedical' => $keralamedical,
                        'frkApplicantEntranceEngineering' => $keralaengg,
                        'frkApplicantEntranceIIT' => $iit,
                        'frkApplicantEntranceJEE' => $jee,
                        'frkAITMT' => $aitmt,
                        'frkAILMS' => $aiims,
                        'frkJITMER' => $jitmer,
                        'frkALIGARH' => $ali,
                        'frkWARDHAH' => $wardhah,
                        'frkAMRITA' => $amrita,
                        'frkMANIPAL' => $manipal,
                        'frkVELLORE' => $vellore,
                        'frkOTHER' => $other,
                    );
                    $this->Applicant->create();
                    if (!$this->Applicant->save($ApplicantTableData)) {
                        $this->Session->setFlash(__('Could not Save Application Data'));
                        return $this->redirect(array('action' => 'primary_registration'));
                    }
                }
                $applicantdetails2 = $this->Applicant->find('first', array(
                    'conditions' => array(
                        'Applicant.frkUserID' => $userid
                    )
                        ));
                $AppNum = $applicantdetails2['Applicant']['frkApplicationNumber'];
                $subject = 'Application has been Entered';
                $message = 'Hello, ' . $this->request->data['PrimaryRegister']['name'] . ' . Your Application has been Entered Your Application Number is ' . $AppNum;
                $to = $this->request->data['PrimaryRegister']['email'];
                $headers = 'From: info@farookadmission.in' . "\r\n" .
                        'Name: Farook College UG Admission' . "\r\n" .
                        'Reply-To: info@farookadmission.in' . "\r\n" .
                        'X-Mailer: PHP/' . phpversion();
                mail($to, $subject, $message, $headers);
                $this->Session->setFlash(__('Thank you .  Please login again when the next page for marks and other details for process your application is open. The date will be open when Kerala HSE results are published.!'));
                return $this->redirect(array('action' => 'applicantinfo'));
            }
            if (!$this->request->data) {
                $this->request->data = $appenddata;
            }
        }

        $setarry = array(
            'countries' => $countries,
            'religions' => $religions,
            'qualifications' => $qualifications,
            'occupations' => $occupations,
            'communities' => $communities,
            'states' => $states,
            'districts' => $districts,
            'entranceData' => $entranceData,
            'ambitions' => $ambitions,
        );
        $this->set($setarry);
    }

    public function test() {
        
    }

    public function forgotpassword() {
        if ($this->request->is('post')) {
            $this->loadModel('User');
            $mail = $this->request->data['UserForgotPassword']['frkUserEmail'];

            $data = $this->User->find('first', array(
                'conditions' => array('frkUserEmail' => $mail),
                'fields' => array('frkUserEmail', 'frkUserID')
                    ));

            if (!$data) {

                $msg = 'No Such E-mail address registerd with us';
                $this->Session->setFlash(__($msg));
                return $this->redirect(array('action' => 'forgotpassword'));
            } else {
                $key = $this->randStrGen(20);
                $sql = "UPDATE `farook`.`users` SET `frkPasswordReset` =  '" . $key . "'  WHERE `users`.`frkUserID` = " . $data['User']['frkUserID'] . " ";
                $this->User->query($sql);

                $id = $data['User']['frkUserID'];
                $to = $data['User']['frkUserEmail'];


                $baseurl = Router::url('/', true);
                $link = $baseurl . "pages/reset/" . $key . "/" . $id;

                $subject = 'Reset password';
                $message1 = "<p>Please click on the link below to reset your password</p>";
                $message2 = "<a href='" . $link . "'>Click here to reset your account password</a>";
                $message3 = "<p>Alternatively, you can also copy paste the below link into your browser:
</p><p>$link</p><p>This email was sent by Farook College Team.</p>";
                $message = $message1 . $message2 . $message3;
                $headers = 'From: admissions@example.com' . "\r\n" .
                        'Reply-To: admissions@example.com' . "\r\n" .
                        'X-Mailer: PHP/' . phpversion();

                $action = mail($to, $subject, $message, $headers);


                /*                 * ************* */


                if ($action) {

                    $msg = 'Please check your email for reset instructions';
                    $this->Session->setFlash(__($msg));
                } else {
                    $msg = 'Something went wrong with activation mail. Please try later';

                    $this->Session->setFlash(__($msg));
                }
            }
            $this->redirect('/');
        }
    }

    public function reset($randstring = NULL, $id = NULL) {

        $data = $this->User->find('first', array(
            'conditions' => array('frkUserID' => $id, 'frkPasswordReset' => $randstring),
            'fields' => array('frkUserID')
                ));
        if (!$data) {
            $message = __('No Such User exists ');
            $this->Session->setFlash($message, 'flash', array('alert' => 'error'));
        } else {
            if ($this->request->is('post')) {
                $password = $this->request->data['UserResetPassword']['frkUserPassword'];
                $confpassword = $this->request->data['UserResetPassword']['frkRepeatUserPassword'];
                $msg = "";
                if ($password == null) {
                    $validates[1] = 'Password Should Not Be Empty';
                }
                if ($confpassword == null) {
                    $validates[2] = 'Confirm Password Should Not Be Empty';
                }
                if ($confpassword != $password) {
                    $validates[3] = 'Password does not Matches';
                }

                if (isset($validates) && $validates != null) {
                    foreach ($validates as $messages) {
                        $msg = $messages . '. ' . $msg . "<br>";
                    }
                    $this->Session->setFlash(__($msg));
                    return $this->redirect(array('action' => 'reset/' . $randstring . '/' . $id));
                } else {
                    $frkUserPassword = base64_encode($password);
                    $sql = "UPDATE `farook`.`users` SET `frkUserPassword` = '" . $frkUserPassword . "', `frkPasswordReset` = ' ' WHERE `users`.`frkUserID` = " . $id . " AND `users`.`frkPasswordReset` = '" . $randstring . "'; ";
                    $this->User->query($sql);
                    $this->Session->setFlash(__('You have changed your password successfully'));
                    return $this->redirect(array('action' => 'index'));
                }
            }
        }
    }

    public function contact() {
        if ($this->request->is('post')) {
            $name = $this->request->data['UserForm']['frkContactName'];
            $email = $this->request->data['UserForm']['frkContactEmail'];
            $message = $this->request->data['UserForm']['frkContactMessage'];
            $messagelength = 500;
            $messagelen = strlen($message);
            $msg = "";
            if ($name == null) {
                $validates[1] = 'Name Should Not Be Empty';
            }
            if ($email == null) {
                $validates[2] = 'Email Should Not Be Empty';
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $validates[3] = "Invalid email format";
            }
            if ($messagelen > $messagelength) {
                $validates[4] = 'Message should not exceed 500 charactes';
            }
            if (isset($validates) && $validates != null) {
                foreach ($validates as $messages) {
                    $msg = $messages . '. ' . $msg . "<br>";
                }
                $this->Session->setFlash(__($msg));
            } else {
                $this->request->data['UserForm']['frkContactStatus'] = 1;

                $this->Contact->create();
                if ($this->Contact->save($this->request->data['UserForm'])) {

                    /*                     * ****Send Mail***** */

                    $baseurl = Router::url('/', true);
                    $to = 'admin@college.com';
                    $from = $email;
                    $subject = 'Contact Mail';
                    $message1 = "Hello Admin, You have got one message from <b>$name</b> <br/>";
                    $message2 = 'Message:' . $message . ' <br/>';
                    $message3 = 'Message From:' . $email . '<br/>';

                    $messagecontent = $message1 . $message2 . $message3;
                    $headers = 'From: ' . $from . "\r\n" .
                            'Reply-To: ' . $from . "\r\n" .
                            'X-Mailer: PHP/' . phpversion();

                    mail($to, $subject, $messagecontent, $headers);

                    /*                     * ***End End Mail**** */

                    $this->Session->setFlash(__('Mail Sent Successfully'));
                } else {
                    die('else');
                    $this->Session->setFlash(__('Unable to send mail,please try again'));
                }
            }
        }
    }
//
    public function photo_upload() {
        if ($this->request->is('post')) {
            if (count($this->request->data['UserForm']['Photo']) > 0) {
                $fileData[] = $this->request->data['UserForm']['Photo'];
            }
            $permitted = array('image/jpeg', 'image/pjpeg', 'image/png');
            $fileOK = $this->uploadFiles('img/profile', $fileData, "", "250", "300", "30",$permitted);
            if (!array_key_exists('urls', $fileOK)) {
                $this->Session->setFlash(__('Please Upload Valid Profile Photo.'));
                return $this->redirect(array('action' => 'secondary_registration'));
            }
            if (array_key_exists('urls', $fileOK)) {

                $this->request->data['UserForm']['Photo'] = $fileOK['urls'][0];
                
            } else if (array_key_exists('errors', $fileOK)) {
                $retArr['errors']['UserForm']['Photo'] = $fileOK['errors'];
                $isCommit = 0;
            } else if (array_key_exists('nofiles', $fileOK)) {
                $this->request->data['UserForm']['Photo'] = 'avatar.png';
            }
        }
    }
    public function applicantinfo() {
        $userid = $this->Session->read('User.userid');
        if (!isset($userid)) {
            $this->Session->setFlash(__('Please Login!.'));
            return $this->redirect(array('action' => 'login'));
        } else {
            $userdata = $this->User->find('first', array(
                'conditions' => array(
                    'User.frkUserID' => $userid
                )
                    ));
//            pr($userdata);
//            exit();
            $applicantdata = array();
            $applicantdata['name'] = $userdata['User']['frkName'];

            if ($userdata['User']['frkUserGender'] == 'M') {
                $applicantdata['gender'] = 'MALE';
            } elseif ($userdata['User']['frkUserGender'] == 'F') {
                $applicantdata['gender'] = 'FEMALE';
            } elseif ($userdata['User']['frkUserGender'] == 'N') {
                $applicantdata['gender'] = 'NUETRAL';
            }
            $applicantdata['email'] = $userdata['User']['frkUserEmail'];
            $applicantdata['mobile'] = $userdata['User']['frkUserMobile'];
            $applicantdata['adhaar'] = $userdata['User']['frkUserAdhaarNo'];
            $getcountry = $this->Country->find('first', array(
                'conditions' => array(
                    'Country.id' => $userdata['User']['frkUserNationality_ID']
                )
                    ));
            $applicantdata['nationality'] = $getcountry['Country']['country_name'];
            if ($userdata['User']['frkUserBloodGroup'] == 'Oplus') {
                $applicantdata['blood'] = 'O+';
            } elseif ($userdata['User']['frkUserBloodGroup'] == 'Oneg') {
                $applicantdata['blood'] = 'O-';
            } elseif ($userdata['User']['frkUserBloodGroup'] == 'Aplus') {
                $applicantdata['blood'] = 'A+';
            } elseif ($userdata['User']['frkUserBloodGroup'] == 'Aneg') {
                $applicantdata['blood'] = 'A-';
            } elseif ($userdata['User']['frkUserBloodGroup'] == 'Bplus') {
                $applicantdata['blood'] = 'B+';
            } elseif ($userdata['User']['frkUserBloodGroup'] == 'Bneg') {
                $applicantdata['blood'] = 'B-';
            } elseif ($userdata['User']['frkUserBloodGroup'] == 'ABplus') {
                $applicantdata['blood'] = 'AB+';
            } elseif ($userdata['User']['frkUserBloodGroup'] == 'ABneg') {
                $applicantdata['blood'] = 'AB-';
            }
            $getcommunity = $this->Community->find('first', array(
                'conditions' => array(
                    'Community.id' => $userdata['User']['frkUserCommunity']
                )
                    ));
            if ($getcommunity == null) {
                $applicantdata['community'] = $userdata['User']['frkUserCommunity'];
            } else {
                $applicantdata['community'] = $getcommunity['Community']['name'];
            }
            $getrelegion = $this->Religion->find('first', array(
                'conditions' => array(
                    'Religion.id' => $userdata['User']['frkUserReligion']
                )
                    ));
            if ($getrelegion == null) {
                $applicantdata['religion'] = $userdata['User']['frkUserReligion'];
            } else {
                $applicantdata['religion'] = $getrelegion['Religion']['name'];
            }
            $applicantdata['placeofbirth'] = $userdata['User']['frkUserPOB'];
            $applicantdata['dob'] = date("d/m/Y", strtotime($userdata['User']['frkUserDOB']));
            $applicantdata['fathername'] = $userdata['User']['frkFatherName'];
            $getfatherqali = $this->Qualification->find('first', array(
                'conditions' => array(
                    'Qualification.id' => $userdata['User']['frkFatherQualification']
                )
                    ));
            if ($getfatherqali == null) {
                $applicantdata['fatherqualification'] = $userdata['User']['frkFatherQualification'];
            } else {
                $applicantdata['fatherqualification'] = $getfatherqali['Qualification']['name'];
            }
            $getfatherocc = $this->Occupation->find('first', array(
                'conditions' => array(
                    'Occupation.id' => $userdata['User']['frkFatherOccupation']
                )
                    ));
            if ($getfatherocc == null) {
                $applicantdata['fatheroccupation'] = $userdata['User']['frkFatherOccupation'];
            } else {
                $applicantdata['fatheroccupation'] = $getfatherocc['Occupation']['name'];
            }
            $applicantdata['mothername'] = $userdata['User']['frkMotherName'];
            $getmotherqali = $this->Qualification->find('first', array(
                'conditions' => array(
                    'Qualification.id' => $userdata['User']['frkMotherQualification']
                )
                    ));
            if ($getmotherqali == null) {
                $applicantdata['motherqualification'] = $userdata['User']['frkMotherQualification'];
            } else {
                $applicantdata['motherqualification'] = $getmotherqali['Qualification']['name'];
            }
            $getmotherocc = $this->Occupation->find('first', array(
                'conditions' => array(
                    'Occupation.id' => $userdata['User']['frkMotherOccupation']
                )
                    ));
            if ($getmotherocc == null) {
                if ($userdata['User']['frkMotherOccupation'] == '0') {
                    $applicantdata['motheroccupation'] = 'House Wife';
                } else {
                    $applicantdata['motheroccupation'] = $userdata['User']['frkMotherOccupation'];
                }
            } else {
                $applicantdata['motheroccupation'] = $getmotherocc['Occupation']['name'];
            }
            $applicantdata['perma-addline1'] = $userdata['User']['frkUserAddressline1'];
            $applicantdata['perma-addline2'] = $userdata['User']['frkUserAddressline2'];
            $applicantdata['perma-post'] = $userdata['User']['frkUserTaluk'];
            $getpermadistrict = $this->District->find('first', array(
                'conditions' => array(
                    'District.id' => $userdata['User']['frkUserDistrict']
                )
                    ));
            if ($getpermadistrict == null) {
                $applicantdata['perma-district'] = $userdata['User']['frkUserDistrict'];
            } else {
                $applicantdata['perma-district'] = $getpermadistrict['District']['name'];
            }

            $getpermastate = $this->State->find('first', array(
                'conditions' => array(
                    'State.id' => $userdata['User']['frkUserState']
                )
                    ));
            if ($getpermastate == null) {
                $applicantdata['perma-state'] = $userdata['User']['frkUserState'];
            } else {
                $applicantdata['perma-state'] = $getpermastate['State']['name'];
            }
            $getpermacountry = $this->Country->find('first', array(
                'conditions' => array(
                    'Country.id' => $userdata['User']['frkUserCountry_ID']
                )
                    ));
            if ($getpermacountry == null) {
                $applicantdata['perma-country'] = $userdata['User']['frkUserCountry_ID'];
            } else {
                $applicantdata['perma-country'] = $getpermacountry['Country']['country_name'];
            }
            $applicantdata['perma-pin'] = $userdata['User']['frkUserPincode'];






            $applicantdata['comm-addline1'] = $userdata['User']['frkUserCommAddressline1'];
            $applicantdata['comm-addline2'] = $userdata['User']['frkUserCommAddressline2'];
            $applicantdata['comm-post'] = $userdata['User']['frkUserCommTaluk'];
            $getcommdistrict = $this->District->find('first', array(
                'conditions' => array(
                    'District.id' => $userdata['User']['frkUserCommDistrict']
                )
                    ));
            if ($getcommdistrict == null) {
                $applicantdata['comm-district'] = $userdata['User']['frkUserCommDistrict'];
            } else {
                $applicantdata['comm-district'] = $getcommdistrict['District']['name'];
            }

            $getcommstate = $this->State->find('first', array(
                'conditions' => array(
                    'State.id' => $userdata['User']['frkUserCommState']
                )
                    ));
            if ($getcommstate == null) {
                $applicantdata['comm-state'] = $userdata['User']['frkUserCommState'];
            } else {
                $applicantdata['comm-state'] = $getcommstate['State']['name'];
            }
            $getcommcountry = $this->Country->find('first', array(
                'conditions' => array(
                    'Country.id' => $userdata['User']['frkUserCommCountryID']
                )
                    ));
            if ($getcommcountry == null) {
                $applicantdata['comm-country'] = $userdata['User']['frkUserCommCountryID'];
            } else {
                $applicantdata['comm-country'] = $getcommcountry['Country']['country_name'];
            }
            $applicantdata['comm-pin'] = $userdata['User']['frkUserCommPincode'];
            $applicantdata['phone'] = $userdata['User']['frkPhoneStd'] . " " . $userdata['User']['frkPhoneStd'];
            $otherdata = $this->Applicant->find('first', array(
                'conditions' => array(
                    'Applicant.frkUserID' => $userid
                )
                    ));
            $applicantdata['tenth'] = $otherdata['Applicant']['frkTenth'];
            $applicantdata['tenthschool'] = $otherdata['Applicant']['frkTenthSchool'];
            $applicantdata['tenthregno'] = $otherdata['Applicant']['frkTenthRegno'];
            $applicantdata['tenthyos'] = $otherdata['Applicant']['frkTenthYOS'];
            $applicantdata['tenthyop'] = $otherdata['Applicant']['frlTenthYOP'];

            $getambition = $this->Ambition->find('first', array(
                'conditions' => array(
                    'Ambition.id' => $otherdata['Applicant']['frkApplicantAmbition']
                )
                    ));
            if ($getambition == null) {
                $applicantdata['career-ambition'] = $otherdata['Applicant']['frkApplicantAmbition'];
            } else {
                $applicantdata['career-ambition'] = $getambition['Ambition']['name'];
            }
            $entrance = array();
            if ($otherdata['Applicant']['frkApplicantEntranceMedical'] == 'Yes') {
                $entrance[1] = 'Kerala Medical';
            }
            if ($otherdata['Applicant']['frkApplicantEntranceEngineering'] == 'Yes') {
                $entrance[2] = 'Kerala Enginerring';
            }
            if ($otherdata['Applicant']['frkApplicantEntranceIIT'] == 'Yes') {
                $entrance[3] = 'IIT';
            }
            if ($otherdata['Applicant']['frkApplicantEntranceJEE'] == 'Yes') {
                $entrance[4] = 'JEE';
            }
            if ($otherdata['Applicant']['frkAITMT'] == 'Yes') {
                $entrance[5] = 'AITMT';
            }
            if ($otherdata['Applicant']['frkAILMS'] == 'Yes') {
                $entrance[6] = 'AILMS';
            }
            if ($otherdata['Applicant']['frkJITMER'] == 'Yes') {
                $entrance[7] = 'JITMER';
            }
            if ($otherdata['Applicant']['frkALIGARH'] == 'Yes') {
                $entrance[8] = 'ALIGARH Medical';
            }
            if ($otherdata['Applicant']['frkWARDHAH'] == 'Yes') {
                $entrance[9] = 'WARDHAH';
            }
            if ($otherdata['Applicant']['frkAMRITA'] == 'Yes') {
                $entrance[10] = 'AMRITA';
            }
            if ($otherdata['Applicant']['frkMANIPAL'] == 'Yes') {
                $entrance[11] = 'MANIPAL';
            }
            if ($otherdata['Applicant']['frkVELLORE'] == 'Yes') {
                $entrance[12] = 'VELLORE';
            }

            $otherentrance = explode("#", $otherdata['Applicant']['frkOTHER']);
            if ($otherentrance[0] == 'Yes') {
                $entrance[13] = $otherentrance[1];
            }
            $applicantdata['entrance'] = $entrance;
            $applicantdata['applicationnumber'] = $otherdata['Applicant']['frkApplicationNumber'];
        }
        $setArray = array(
            'applicantdata' => $applicantdata
        );
        $this->set($setArray);
    }
    public function secondary_registration() {

        /* $userid = $this->Session->read('User.userid');
          if (!isset($userid)) {
          $this->Session->setFlash(__('Please Login!.'));
          return $this->redirect(array('action' => 'login'));
          }
          else */
        if ($this->request->is('post')) {
            //pr($this->request->data);
           
            $academicdetails = array(
                'boardID' => $this->request->data['SecondaryRegister']['qualifyingexam'],
                'frkUserID' => 1,
                'institution' => $this->request->data['SecondaryRegister']['institution'],
                'yearOfstudy' => $this->request->data['SecondaryRegister']['yearOfstudy'],
                'registerNumber' => $this->request->data['SecondaryRegister']['registerNumber'],
                'yearOfPass' => $this->request->data['SecondaryRegister']['yearOfPass'],
                'TcnoDate' => $this->request->data['SecondaryRegister']['TcnoDate'],
            );
             $this->Academicdetail->create();
              
              if (!$this->Academicdetail->save($academicdetails)) {
              $this->Session->setFlash(__('Could not Save Application Data'));
              return $this->redirect(array('action' => 'secondary_registration'));
              } 
        }
        $courses = $this->Course->find('list', array('fields' => array('frkCourseID', 'frkCourseName')));
        $this->set('courses', $courses);
        $examboards = $this->Examboard->find('list', array('fields' => array('boardID', 'boardName')));
        $this->set('examboards', $examboards);
    }

  
}
